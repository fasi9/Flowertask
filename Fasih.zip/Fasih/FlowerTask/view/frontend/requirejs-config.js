var config = {
    config: {
        mixins: {
            'Magento_Checkout/js/action/place-order': {
                'Fasih_FlowerTask/js/order/flower-order-mixin': true
            },
        }
    }
};
